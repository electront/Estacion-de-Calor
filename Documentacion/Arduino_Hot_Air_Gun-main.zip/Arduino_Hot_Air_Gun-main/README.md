# Arduino_Hot_Air_Gun

The detailed description available on hackster.io: https://www.hackster.io/makerbr555/diy-smd-rework-station-28b6f5

Release history:
Jan 6 2022, version 2.00
* The hardware part revisited
* The firmware part revisited and recreated

